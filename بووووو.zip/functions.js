document.addEventListener("DOMContentLoaded", function() {
    const sidebar = document.getElementById("sidebar");
    const openSidebarBtn = document.getElementById("openSidebarBtn");
    const closeSidebarBtn = document.getElementById("closeSidebarBtn");

    openSidebarBtn.addEventListener("click", function() {
        sidebar.classList.add("open");
    });

    closeSidebarBtn.addEventListener("click", function() {
        sidebar.class